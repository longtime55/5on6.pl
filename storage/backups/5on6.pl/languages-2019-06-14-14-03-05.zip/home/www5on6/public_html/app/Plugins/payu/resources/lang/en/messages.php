<?php

return [
    'Payment Details' => 'Payment Details',
    'Payment with PayU' => 'Payment with PayU',
];